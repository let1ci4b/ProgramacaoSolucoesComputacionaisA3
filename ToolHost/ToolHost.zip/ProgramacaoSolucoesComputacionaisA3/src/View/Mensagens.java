package View;


public class Mensagens extends Exception {

    Mensagens(String msg) {
        super(msg);
    }
}
