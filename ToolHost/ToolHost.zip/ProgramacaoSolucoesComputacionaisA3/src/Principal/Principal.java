package Principal;

import View.TelaMenu;


public class Principal {

    public static void main(String[] args) {
        new TelaMenu().setVisible(true);
    }
}
