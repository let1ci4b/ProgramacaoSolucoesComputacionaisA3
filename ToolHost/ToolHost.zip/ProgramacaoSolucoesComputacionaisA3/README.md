# 😎 A3 de Programação de Soluções Computacionais
Repositório criado com o intuito de abrigar as entregas para a A3 da UC Programação de Soluções Computacionais.
#

### 👨🏻‍💻 Integrantes: 
```
Davi Garcia Bruck
Curso: Ciência da computação
RA: 1072310456
Celular: (48) 99689-0856

------------------------------------------------

Guilherme Izaias Fernandes
Curso: Ciência da computação
RA:  1072312029
Celular: (48) 99865-2111

------------------------------------------------

Guilherme Lima
Curso: Ciência da computação
RA: 10723115132
Celular: (48) 99182-8318

------------------------------------------------

Isaías Palomanes Correia
Curso: Análise e desenvolvimento de sistemas - semipresencial
RA: 10723114642
Celular: (48) 99828-6772

------------------------------------------------

João Guilherme da Silva Porfirio 
Curso: Ciência da computação
RA: 10723111590
Celular: (48) 98416-1284

------------------------------------------------

Letícia Beatriz Souza
Curso: Sistemas de informação
RA: 1072318584
Celular: (48) 99686-2073

------------------------------------------------

Renan Pando de Melo Machado
Curso: Ciência da computação
RA: 1072316421
Celular: (48) 99173-2599

```

#

### 🖥️ Código fonte:

#### [Arquivo compactado com scripts SQL](ToolHost/ToolHost.zip)

#### [GitHub](src)

#

### 🎲 Banco de dados:

#### [GitHub - Scripts SQL](ScriptSQL)

#

### 🎥 [Vídeo Pitch](https://drive.google.com/file/d/1RgxrBoL3kwzEEorCybZ97PbYOtOW94RW/view?usp=sharing)

#
